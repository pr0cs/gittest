package net.pixelsystems.state;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import net.pixelsystems.client.Client;
import net.pixelsystems.server.CameraData;

public class WhosHomeState {

	public static void saveState(List<Client>clients){
		JsonWriter writer =null;
		try{
		Gson saveState = new Gson();
		Type listType = new TypeToken<List<Client>>(){}.getType();
		String test = saveState.toJson(clients,listType);
		FileOutputStream fout = new FileOutputStream(new File("test.json"));
		writer = new JsonWriter(new OutputStreamWriter(fout,"UTF-8"));
		writer.beginObject();
		writer.name("clients").value(test);
		writer.endObject();
		writer.close();
		System.out.println(test);
		}catch(Exception ex){
			ex.printStackTrace();
			if(writer!=null){
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	public static void readState() {
		JsonReader reader = null;
		try{
			FileInputStream fin = new FileInputStream(new File("test.json"));
			reader = new JsonReader(new InputStreamReader(fin,"UTF-8"));
			Gson login = new Gson();
			reader.beginObject();
		     while (reader.hasNext()) {
		       String name = reader.nextName();
		       //reader.nextString()
				Type listType = new TypeToken<List<Client>>(){}.getType();
				Object clientObj = login.fromJson(reader.nextString(), listType);
		       
		       System.out.println(name);
		       
				
				
				//Object clientObj = login.fromJson(reader, listType);
				//List<CameraData>cams = (List<CameraData>) camObj;

		       
		     }
		     reader.endObject();
		     reader.close();
		}catch(Exception ex){
			ex.printStackTrace();
			if(reader!=null){
				try {
					reader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
}
